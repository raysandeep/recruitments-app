
import 'package:flutter/material.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';



void main() => runApp(new Forma());

class Forma extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    var formPage = new FormPage();
        return new MaterialApp(
          debugShowCheckedModeBanner: false,
          home: formPage,
    );
  }
}

class FormPage extends StatefulWidget {
  
  @override
  _FormPageState createState() => new _FormPageState();
}


class _FormPageState extends State<FormPage> {
  bool _management =false;
  bool _technical=false;
  bool _design=false;
  double _skillLevel = 1;
  double _capabilityLevel = 1;
  double _depthLevel=1;

  
 String _counter,_val = "";

  Future _Scanner() async{
    _counter = await FlutterBarcodeScanner.scanBarcode("#004297","Cancel",true);
    setState(() {
      _val=_counter;
      
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        resizeToAvoidBottomPadding: false,
        body: ListView(
          children: <Widget>[
            Container(
              child: Stack(
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.fromLTRB(15.0, 60.0, 0.0, 0.0),
                    child: Text('Form',
                        style: TextStyle(
                            fontSize: 60.0, fontWeight: FontWeight.bold)),
                                  ),
                                  
                                ],
                              ),
                            ),
                      Container(
                          padding: EdgeInsets.only(top: 35.0, left: 20.0, right: 20.0),
                          child: Column(
                            children: <Widget>[
                              Text(
                        '$_val',
                        style: Theme.of(context).textTheme.display1,
                      ),
                      SizedBox(height:50),
                      Container(
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.black,
                        ),
                        child: GestureDetector(
                          child: Text("Scan" , style:TextStyle(color: Colors.white,fontSize: 20)),
                          onTap: _Scanner,
                        ),

                      ),
                      Slider.adaptive(
                      value: _skillLevel.toDouble(),
                      onChanged: (double newValue) {
                        setState(() {
                          _skillLevel = newValue;
                        });
                      },
                      activeColor: Colors.black,
                      min: 0,
                      max: 10,
                      divisions: 10,
                      label: _skillLevel.toString(),
                  ),
                    Container(
                      alignment: Alignment(1.0, 0.0),
                      padding: EdgeInsets.only(top: 15.0, left: 20.0),
                        child: Text(
                          'Skills',
                          style: TextStyle(
                              color: Colors.green,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Montserrat'),
                        ),
                      
                    ),
                    SizedBox(height: 20.0),
                    Slider.adaptive(
                      value: _capabilityLevel.toDouble(),
                      onChanged: (double newValue) {
                        setState(() {
                          _capabilityLevel = newValue;
                        });
                      },
                      activeColor: Colors.black,
                      min: 0,
                      max: 10,
                      divisions: 10,
                      label: _capabilityLevel.toString(),
                  ),
                    Container(
                      alignment: Alignment(1.0, 0.0),
                      padding: EdgeInsets.only(top: 15.0, left: 20.0),
                        child: Text(
                          'Capability',
                          style: TextStyle(
                              color: Colors.green,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Montserrat'),
                        ),
                      
                    ),
                    SizedBox(height: 20.0),
                    Slider.adaptive(
                      value: _depthLevel.toDouble(),
                      onChanged: (double newValue) {
                        setState(() {
                          _depthLevel = newValue;
                        });
                      },
                      activeColor: Colors.black,
                      min: 0,
                      max: 10,
                      divisions: 10,
                      label: _depthLevel.toString(),
                  ),
                    Container(
                      alignment: Alignment(1.0, 0.0),
                      padding: EdgeInsets.only(top: 15.0, left: 20.0),
                        child: Text(
                          'Knowledge Depth',
                          style: TextStyle(
                              color: Colors.green,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Montserrat'),
                        ),
                      
                    ),
                    Container(
                    padding: EdgeInsets.fromLTRB(16.0, 30.0, 0.0, 0.0),
                    child: Text('Domain',
                        style: TextStyle(
                            fontSize: 25.0, fontWeight: FontWeight.bold)),
                  ),
                    SizedBox(height: 5.0),
                    CheckboxListTile(
                      value: _management,
                      title:Text('Management'),
                      onChanged: (bool value){
                        setState(() {
                          _management = value;
                        });
                      },
                    ),
                    SizedBox(height: 5.0),
                    CheckboxListTile(
                      value: _technical,
                      title:Text('Technical'),
                      onChanged: (bool value){
                        setState(() {
                          _technical = value;
                        });
                      },
                    ),
                    SizedBox(height: 5.0),
                    CheckboxListTile(
                      value: _design,
                      title:Text('Design'),
                      onChanged: (bool value){
                        setState(() {
                          _design = value;
                        });
                      },
                    ),
                    SizedBox(height: 40.0),
                    Container(
                      height: 40.0,
                      child: Material(
                        borderRadius: BorderRadius.circular(20.0),
                        shadowColor: Colors.black,
                        color: Colors.black,
                        elevation: 7.0,
                        child: GestureDetector(
                          onTap: () {

                          },
                          child: Center(
                            child: Text(
                              'SUUBMIT',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Montserrat'),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20.0),
                  ],
                )),
            SizedBox(height: 15.0),
          ],
        ));
  }
}
