import 'package:flutter/material.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'form.dart';

void main() => runApp(MyBarcode());

class MyBarcode extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {


  @override
  _BarcodeState createState() => new _BarcodeState();
}

class _BarcodeState extends State<MyHomePage> {
  String _counter,_val = "";

  Future _Scanner() async{
    _counter = await FlutterBarcodeScanner.scanBarcode("#004297","Cancel",true);
    setState(() {
      _val=_counter;
      
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.black,
              ),
              child: GestureDetector(
                child: Text("Barcode" , style:TextStyle(color: Colors.white,fontSize: 20)),
                onTap: _Scanner,
              ),

            ),
            SizedBox(height:50),
            Text(
              '$_val',
              style: Theme.of(context).textTheme.display1,
            ),
            SizedBox(height:50),
             Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.black,
              ),
              child: GestureDetector(
                child: Text("Form" , style:TextStyle(color: Colors.white,fontSize: 20)),
                onTap: (){
                  Navigator.of(context).push( new MaterialPageRoute(builder: (context){
                    return new Forma();
                  }),
                  );
                },
              ),

            ),
          ],
        ),
      ),
    );
  }
}
